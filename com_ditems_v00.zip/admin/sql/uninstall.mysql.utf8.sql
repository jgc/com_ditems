DROP TABLE IF EXISTS `#__diaryitems`;
DROP TABLE IF EXISTS `#__diary_dogs`;
